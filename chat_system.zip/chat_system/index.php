<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="css/style.css" />
	
	<script
		src="https://code.jquery.com/jquery-3.2.1.js"
		integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
		crossorigin="anonymous">
	</script>
	<title></title>
</head>
<body>
 <?php 
	//session_destroy();

 ?>
	
	<div id="wrapper">
		<h1>Welcome <?php session_start(); echo $_SESSION['username']; ?> to our Chat box</h1>
		
		
		<div class="chat-wrapper">
		<div id="chat"></div>
			<form method="POST" action="" id="messageFrm">
				<textarea class="textarea" name="" id="" cols="30" rows="7" placeholder="Write your message here....."></textarea>
			</form>
		</div>

	</div>
	
	<script>
	
		Loadchat();
		setInterval(function(){
			Loadchat();
		}, 1000);
		function Loadchat(){
			$.post('handlers/messages.php?action=getMessages', function(response){
				//for scroll always on down
				var scrollpos = $('#chat').scrollTop();
				var scrollpos = parseInt(scrollpos) + 520;
				var scrollHeight = $('#chat').prop('scrollHeight');
				//for scroll always on down
				$('#chat').html(response);
				
				
				if(scrollpos < scrollHeight){
					
				}else{
					$('#chat').scrollTop($('#chat').prop('scrollHeight'));
				}			
				
			});
		}
	
	
	//alert when pressing enter
		$('.textarea').keyup(function(e){if(e.which == 13){$('form').submit();}});
	//submit the mesage using jquery
		$('form').submit(function(){
			var message = $('.textarea'). val();
			$.post('handlers/messages.php?action=sendMessage&message='+message, function(response){
				
				if(response == 1){
					Loadchat();
					document.getElementById('messageFrm').reset();
				}
				
			});
			return false;
		});
		
	</script>
	
	
	
	
	
	
	
	
	
	
	
</body>
</html>