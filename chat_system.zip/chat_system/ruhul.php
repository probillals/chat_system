 <?php 
	session_start();
	$_SESSION['username'] = "Ruhul Amin";

 ?>