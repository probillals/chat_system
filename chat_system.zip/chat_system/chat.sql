-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2017 at 03:57 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chat`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
`id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user`, `message`, `date`) VALUES
(32, 'Ruhul Amin', 'hello everyone', '2017-11-30 14:09:57'),
(33, 'Ruhul Amin', 'Hi', '2017-11-30 14:10:02'),
(34, 'Ruhul Amin', 'Are you', '2017-11-30 14:10:12'),
(35, 'Billal Hossain', 'hi', '2017-11-30 14:10:48'),
(36, 'Mou', 'hello', '2017-11-30 14:11:07'),
(37, 'Mou', 'hgrh', '2017-11-30 14:11:19'),
(38, 'Ruhul Amin', 'hi', '2017-11-30 14:11:32'),
(39, 'Ruhul Amin', 'what is my name', '2017-11-30 14:11:47'),
(40, 'Ruhul Amin', 'what is my name', '2017-11-30 14:11:53'),
(41, 'Ruhul Amin', 'oirhg', '2017-11-30 14:11:57'),
(42, 'Ruhul Amin', 'ho', '2017-11-30 14:13:06'),
(43, 'Ruhul Amin', 'hi', '2017-11-30 14:13:08'),
(44, 'Billal Hossain', 'hi', '2017-11-30 14:14:30'),
(45, 'Ruhul Amin', 'hello', '2017-11-30 14:14:35'),
(46, 'Ruhul Amin', 'gh', '2017-11-30 14:24:15'),
(47, 'Ruhul Amin', 'hgi', '2017-11-30 14:24:16'),
(48, 'Ruhul Amin', 'ghg', '2017-11-30 14:24:17'),
(49, 'Ruhul Amin', 'gjhgjg', '2017-11-30 14:24:17'),
(50, 'Ruhul Amin', 'gjgjg', '2017-11-30 14:24:18'),
(51, 'Ruhul Amin', 'gjgj', '2017-11-30 14:24:19'),
(52, 'Ruhul Amin', 'hello', '2017-11-30 14:31:06'),
(53, 'Billal Hossain', 'hello', '2017-11-30 14:38:45'),
(54, 'Ruhul Amin', 'yes', '2017-11-30 14:38:51'),
(55, 'Ruhul Amin', 'oh', '2017-11-30 14:38:56'),
(56, 'Billal Hossain', 'no', '2017-11-30 14:38:59'),
(57, 'Billal Hossain', 'no', '2017-11-30 14:39:01'),
(58, 'Billal Hossain', 'no', '2017-11-30 14:39:02'),
(59, 'Ruhul Amin', '', '2017-11-30 14:40:37'),
(60, 'Ruhul Amin', '', '2017-11-30 14:40:38'),
(61, 'Ruhul Amin', '', '2017-11-30 14:40:39'),
(62, 'Ruhul Amin', '', '2017-11-30 14:40:39'),
(63, 'Ruhul Amin', '', '2017-11-30 14:40:40'),
(64, 'Ruhul Amin', '', '2017-11-30 14:40:44'),
(65, 'Ruhul Amin', '', '2017-11-30 14:40:44'),
(66, 'Ruhul Amin', '', '2017-11-30 14:40:45'),
(67, 'Ruhul Amin', '', '2017-11-30 14:40:45'),
(68, 'Ruhul Amin', '', '2017-11-30 14:40:46'),
(69, 'Ruhul Amin', 'GHFG', '2017-11-30 14:56:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
